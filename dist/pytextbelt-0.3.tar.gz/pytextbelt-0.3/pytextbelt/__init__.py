import requests
from . import Textbelt
